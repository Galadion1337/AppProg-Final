package controller;

/*
 * Created by Galadion1337 and ruelasac as a part of Application Programming 3443.001 class
 */
import java.net.URL;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainViewController {

    @FXML
    private TextField txtName;//textbox for name in the entrance window

    @FXML
    private Label lblBadLogin;//label to let you know to enter a name on the entrance window
    
    @FXML
    private Button btnEnter;//basically to enter the main window from the entrance window
    
    //Text fields for Quiz Answers
    @FXML
    private TextField txtA1;
    
    @FXML
    private TextField txtA2;
    
    @FXML
    private TextField txtA3;
    
    @FXML
    private TextField txtA4;
    
    @FXML
    private TextField txtA5;
    
    @FXML
    private TextField txtA6;
    
    @FXML
    private Label lblAnsStatus;
    
    @FXML
    private Button btnResults;
	
    //Allows entrance into the main application body
    @FXML
    void Enter(ActionEvent event) throws Exception {
    	if(txtName.getText().equals("")) {
    		lblBadLogin.setText("Please Enter a Name");
    	} else {
    		//enter into main screen
    		Stage stage = new Stage();
    		URL fxmlFile = this.getClass().getResource("../view/MainScreen.fxml");
    		FXMLLoader loader = new FXMLLoader(fxmlFile);
    		MainViewController main = new MainViewController();
    		loader.setController(main);
    		BorderPane rootNode = new BorderPane();
    		rootNode.setCenter(loader.load());
    		
    		Scene scene = new Scene(rootNode, 700, 400);
    		stage.setResizable(false);
    		stage.setTitle("Small Buds");
    		stage.setScene(scene);
    		stage.show();
    		
    		//on pressing the "Enter" button successfully, close this window after opening the main window
    		Stage close = (Stage) btnEnter.getScene().getWindow();
			close.close();
    	}

    }
    
    //Creates the information window for the Panda Plant
    @FXML
    void startSuccPanda(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/SuccPanda.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for the Bear Paw Succulent
    @FXML
    void startSuccBearPaw(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/SuccBearPaw.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for the Echeveria Succulent
    @FXML
    void startSuccEcheveria(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/SuccEcheveria.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for the Zebra Plant
    @FXML
    void startSuccZebraPlant(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/SuccZebraPlant.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Basil
    @FXML
    void startHerbBasil(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/HerbBasil.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Mint
    @FXML
    void startHerbMint(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/HerbMint.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }

    //Creates the information window for Rosemary
    @FXML
    void startHerbRosemary(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/HerbRosemary.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Lavender
    @FXML
    void startHerbLavender(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/HerbLavender.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Coneflower
    @FXML
    void startFlowConeflower(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/FlowConeflower.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Pansy
    @FXML
    void startFlowPansy(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/FlowPansy.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Rose
    @FXML
    void startFlowRose(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/FlowRose.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for Marigold
    @FXML
    void startFlowMarigold(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/FlowMarigold.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 600, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the information window for the About section
    @FXML
    void startAboutApp(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/AboutView.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 300, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
    }
    
    //Creates the quiz window
    @FXML
    void startQuizQts(ActionEvent event) throws Exception {
    	Stage stage = new Stage();
		URL fxmlFile = this.getClass().getResource("../view/QuizQts.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 500, 700);
		
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
		
    }
    
    //gets quiz results
    @FXML
    void getAnswers(ActionEvent event) throws Exception {
    	int SuccTotal = 0;
    	int HerbTotal = 0;
    	int FlowTotal = 0;
    	if(txtA1.getText().equals("") || txtA2.getText().equals("") || txtA3.getText().equals("") || txtA4.getText().equals("") || txtA5.getText().equals("") || txtA6.getText().equals("")) {
    		//if a field is left blank error
    		lblAnsStatus.setText("Field Left Blank");
    	} else if ( (txtA1.getText().equals("A") || txtA1.getText().equals("B")) && 
    			(txtA2.getText().equals("A") || txtA2.getText().equals("B")) && 
    			(txtA3.getText().equals("A") || txtA3.getText().equals("B")) && 
    			(txtA4.getText().equals("A") || txtA4.getText().equals("B") || txtA4.getText().equals("C")) &&
    			(txtA5.getText().equals("A") || txtA5.getText().equals("B") || txtA5.getText().equals("C")) &&
    			(txtA6.getText().equals("A") || txtA6.getText().equals("B") || txtA6.getText().equals("C")) ) {
    		//weight calc for Q1
    		if(txtA1.getText().equals("A")) {
    			SuccTotal += 5;
    			HerbTotal += 10;
    			FlowTotal += 15;
    		} else if (txtA1.getText().equals("B")) {
    			SuccTotal += 15;
    			HerbTotal += 10;
    			FlowTotal += 5;
    		}
    		
    		//weight calc for Q2
    		if(txtA2.getText().equals("A")) {
    			SuccTotal += 5;
    			HerbTotal += 15;
    			FlowTotal += 10;
    		} else if (txtA2.getText().equals("B")) {
    			SuccTotal += 15;
    			HerbTotal += 5;
    			FlowTotal += 10;
    		}
    		
    		//weight calc for Q3
    		if(txtA3.getText().equals("A")) {
    			SuccTotal += 10;
    			HerbTotal += 15;
    			FlowTotal += 5;
    		} else if (txtA3.getText().equals("B")) {
    			SuccTotal += 10;
    			HerbTotal += 5;
    			FlowTotal += 15;
    		}
    		
    		//weight calc for Q4
    		if(txtA4.getText().equals("A")) {
    			SuccTotal += 15;
    			HerbTotal += 5;
    			FlowTotal += 10;
    		} else if (txtA4.getText().equals("B")) {
    			SuccTotal += 10;
    			HerbTotal += 5;
    			FlowTotal += 15;
    		} else if (txtA4.getText().equals("C")) {
    			SuccTotal += 5;
    			HerbTotal += 15;
    			FlowTotal += 10;
    		}
    		
    		//weight calc for Q5
    		if(txtA5.getText().equals("A")) {
    			SuccTotal += 15;
    			HerbTotal += 10;
    			FlowTotal += 5;
    		} else if (txtA5.getText().equals("B")) {
    			SuccTotal += 10;
    			HerbTotal += 15;
    			FlowTotal += 5;
    		} else if (txtA5.getText().equals("C")) {
    			SuccTotal += 5;
    			HerbTotal += 10;
    			FlowTotal += 15;
    		}
    		
    		//weight calc for Q6
    		if(txtA6.getText().equals("A")) {
    			HerbTotal += 15;
    		} else if (txtA6.getText().equals("B")) {
    			FlowTotal += 15;
    		} else if (txtA6.getText().equals("C")) {
    			SuccTotal += 15;
    		}
    		
    		//create results screen
    		if( (SuccTotal >= HerbTotal) && (SuccTotal >= FlowTotal) ) {
    			//create Succ results window
    			//System.out.println("Succulent");
    			Stage stage = new Stage();
    			URL fxmlFile = this.getClass().getResource("../view/ResultSucc.fxml");
    			FXMLLoader loader = new FXMLLoader(fxmlFile);
    			MainViewController main = new MainViewController();
    			loader.setController(main);
    			BorderPane rootNode = new BorderPane();
    			rootNode.setCenter(loader.load());
    			
    			Scene scene = new Scene(rootNode, 400, 300);
    			
    			stage.setResizable(false);
    			stage.setTitle("Small Buds");
    			stage.setScene(scene);
    			stage.show();
    		} else if ( (HerbTotal >= SuccTotal) && (HerbTotal >= FlowTotal) ) {
    			//create Herb results window
    			//System.out.println("Herb");
    			Stage stage = new Stage();
    			URL fxmlFile = this.getClass().getResource("../view/ResultHerb.fxml");
    			FXMLLoader loader = new FXMLLoader(fxmlFile);
    			MainViewController main = new MainViewController();
    			loader.setController(main);
    			BorderPane rootNode = new BorderPane();
    			rootNode.setCenter(loader.load());
    			
    			Scene scene = new Scene(rootNode, 400, 300);
    			
    			stage.setResizable(false);
    			stage.setTitle("Small Buds");
    			stage.setScene(scene);
    			stage.show();
    		} else if ( (FlowTotal >= HerbTotal) && (FlowTotal >= SuccTotal) ) {
    			//create Flow results window
    			//System.out.println("Flower");
    			Stage stage = new Stage();
    			URL fxmlFile = this.getClass().getResource("../view/ResultFlow.fxml");
    			FXMLLoader loader = new FXMLLoader(fxmlFile);
    			MainViewController main = new MainViewController();
    			loader.setController(main);
    			BorderPane rootNode = new BorderPane();
    			rootNode.setCenter(loader.load());
    			
    			Scene scene = new Scene(rootNode, 400, 300);
    			
    			stage.setResizable(false);
    			stage.setTitle("Small Buds");
    			stage.setScene(scene);
    			stage.show();
    		}
    	} else {
    		//input error
    		lblAnsStatus.setText("Error in the input");
    	}
    	//System.out.println("Succulent: " + SuccTotal + "\nHerb: " + HerbTotal + "\nFlower: " + FlowTotal);
    }

}
