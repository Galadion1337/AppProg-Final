package model;

/*
 * Created by Galadion1337 and ruelasac as a part of Application Programming 3443.001 class
 */
public class ModelClass {
	
	
}