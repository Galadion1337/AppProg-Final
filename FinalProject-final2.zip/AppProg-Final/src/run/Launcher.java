package run;

/*
 * Created by Galadion1337 and ruelasac as a part of Application Programming 3443.001 class
 */
import java.net.URL;

import controller.MainViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Launcher extends Application {

	//creates the stage and the entrance frame which leads to everything else
	@Override
	public void start(Stage stage) throws Exception {
		URL fxmlFile = this.getClass().getResource("../view/EnterScreen.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 300, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
	}
	
	@Override
	public void stop() throws Exception {
		super.stop();
	}
	
	//launches the app
	public static void main(String[] args) {
		launch(args);
	}
	
}
