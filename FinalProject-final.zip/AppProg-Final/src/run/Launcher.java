package run;

import java.net.URL;

import controller.MainViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Launcher extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		URL fxmlFile = this.getClass().getResource("../view/EnterScreen.fxml");
		FXMLLoader loader = new FXMLLoader(fxmlFile);
		MainViewController main = new MainViewController();
		loader.setController(main);
		BorderPane rootNode = new BorderPane();
		rootNode.setCenter(loader.load());
		
		Scene scene = new Scene(rootNode, 300, 400);
		stage.setResizable(false);
		stage.setTitle("Small Buds");
		stage.setScene(scene);
		stage.show();
	}
	
	@Override
	public void stop() throws Exception {
		super.stop();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
}
